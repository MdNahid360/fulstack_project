import React from 'react';

const Admin = () => {
    return (
        <div>
            <h1>Admin component is under construction.</h1>
        </div>
    );
};

export default Admin;