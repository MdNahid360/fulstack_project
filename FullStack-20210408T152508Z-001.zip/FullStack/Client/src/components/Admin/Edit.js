import React from 'react';

const Edit = () => {
    return (
        <div>
            <h2>Edit component is under construction.</h2>
        </div>
    );
};

export default Edit;