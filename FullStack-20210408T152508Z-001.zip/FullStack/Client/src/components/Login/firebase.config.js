const firebaseConfig = {
    apiKey: 'AIzaSyAZSodyMdrDaVogy7Gcxy0jqLZAaL8KubA',
    authDomain: 'fullstack-auth-c5217.firebaseapp.com',
    projectId: 'fullstack-auth-c5217',
    storageBucket: 'fullstack-auth-c5217.appspot.com',
    messagingSenderId: '491521819209',
    appId: '1:491521819209:web:1151b89357e84697aa7598',
};
export default firebaseConfig;